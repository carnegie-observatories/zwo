/* ----------------------------------------------------------------
 *
 * cxt_edit.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
#ifdef FONTSIZE
#define PXh             FONTSIZE
#else
#define PXh             14             /* default fontsize */
#endif
#define PXw             (10+(PXh-14)/2)
#define XXh             (PXh+4)

#define PREFUN          __func__

/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <stdio.h>
#include <string.h>                    /* strcpy(),strlen() */

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern Application *cbx_app;

/* function prototype(s) */


/* STATICs -------------------------------------------------------- */

static void cbx_UpdateEditList(MainWindow*,EditWindow*,
                               void(*callback)(void*),int);


/* ---------------------------------------------------------------- */
/* EditWindow routines */
/* ---------------------------------------------------------------- */

static void cbx_UpdateEditList(MainWindow* mw,EditWindow* ewin,
                        void(*callback)(void*),int flag)
{
  ManagedObject object;
#if (DEBUG > 1)
  fprintf(stderr,"%s(%p) enter ...\n",PREFUN,(void*)&mw->elist);
#endif

  object.object   = (void*)ewin;
  object.callback = callback;

  if (flag > 0) CBX_AddList(&(mw->elist),&object); /* add to list */
  else          CBX_RemList(&(mw->elist),&object);
#if (DEBUG > 1)
  fprintf(stderr,"%s(%p) done\n",PREFUN,(void*)&mw->elist);
#endif
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoEdit(MainWindow* mw,EditWindow* ewin,
                          int x,int y,int w,int h,char* text,int mode,
                          void(*callback)(void*))
{
  Window win;

  win = CBX_CreateEditWindow(mw,ewin,x,y,w,h,2,text,mode|CBX_AUTO);
#if 0 /* cut/paste */
  CBX_SelectInput_Ext(mw->disp,win,KeyPressMask | EnterWindowMask |
                      LeaveWindowMask | ButtonPressMask | PropertyChangeMask);
#else
  CBX_SelectInput_Ext(mw->disp,win,KeyPressMask | EnterWindowMask |
                      LeaveWindowMask | ButtonPressMask);
#endif
  cbx_UpdateEditList(mw,ewin,callback,1);

  return(win);
}

/* --- */

Window CBX_CreateAutoEdit_Ext(MainWindow* mw,    /* v4.080 */
                          EditWindow* ewin,Window parent,
                          int x,int y,int w,int h,char* text,int mode,
                          void(*callback)(void*))
{
  Window win;

  win = CBX_CreateEditWindow_Ext(mw,ewin,parent,mw->gfs,x,y,w,h,2,
                                 text,mode|CBX_AUTO);
  CBX_SelectInput_Ext(mw->disp,win,KeyPressMask | EnterWindowMask |
                      LeaveWindowMask | ButtonPressMask);
  cbx_UpdateEditList(mw,ewin,callback,1);

  return(win);
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoOutput(MainWindow* mw,EditWindow* ewin,
                           int x,int y,int w,int h,char* text)
{
  Window win;

  win = CBX_CreateEditWindow(mw,ewin,x,y,w,h,1,text,CBX_AUTO);
  CBX_Flush(mw);
  CBX_DisableEditWindow(ewin,CBX_DISABLED);
  cbx_UpdateEditList(mw,ewin,NULL,1);

  return(win);
}

/* --- */

Window CBX_CreateAutoOutput_Ext(MainWindow* mw,  /* v4.080 */
                                EditWindow* ewin,Window parent,
                                int x,int y,int w,int h,char* text)
{
  Window win;

  win = CBX_CreateEditWindow_Ext(mw,ewin,parent,mw->gfs,x,y,w,h,1,
                                 text,CBX_AUTO);
  CBX_Flush(mw);
  CBX_DisableEditWindow(ewin,CBX_DISABLED);
  cbx_UpdateEditList(mw,ewin,NULL,1);

  return(win);
}

/* ---------------------------------------------------------------- */

Window CBX_CreateEditWindow(MainWindow* mw,EditWindow* ewin,int x,int y,
                            int w,int h,int b,char* text,int mode)
{
  Window win;

  win = CBX_CreateEditWindow_Ext(mw,ewin,mw->win,mw->gfs,x,y,w,h,b,text,mode);
  CBX_SelectInput_Ext(mw->disp,win,KeyPressMask | EnterWindowMask |
                                   LeaveWindowMask);

  return(win);
}

/* ---------------------------------------------------------- */

Window CBX_CreateEditWindow_Ext(MainWindow* mw,EditWindow* ewin,Window parent,
                            GfC gfs,int x,int y,int w,int h,int b,char* text,
                            int mode)
{
  Window win;
#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) enter ...\n",PREFUN,(void*)mw->disp);
#endif

  ewin->mwin = mw;
  ewin->disp = mw->disp;
  ewin->bg   = cbx_app->beige;         /* default colors */
  ewin->fg   = cbx_app->black;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,b,cbx_app->black,ewin->bg);
  XSelectInput(mw->disp,win,KeyPressMask | EnterWindowMask | LeaveWindowMask);

  XMapRaised(mw->disp,win);
  CBX_Unlock();

  ewin->gfs    = gfs;
  ewin->win    = win;
  ewin->x      = x;
  ewin->y      = y;
  ewin->w      = w;
  ewin->h      = h;
  ewin->flag   = CBX_NORMAL;
  if (text) (void)strcpy(ewin->text,text);
  else      (void)strcpy(ewin->text,"");
  ewin->cpos   = strlen(ewin->text);
  ewin->show_cursor = False;
  ewin->buf[0] ='\0';
  ewin->mode = mode;

#if 0 /* O-O */
  ewin->update = CBX_UpdateEditWindow();
#endif

#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) leave\n",PREFUN,(void*)ewin->disp);
#endif

  return(win);
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
