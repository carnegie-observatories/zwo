/* ----------------------------------------------------------------
 *
 * cxt_cmenu.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
#define PREFUN          __func__

/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <string.h>                    /* strcpy(),strlen() */

#if (DEBUG > 0)
#include <stdio.h>                     /* fprintf() */
#endif

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern Application *cbx_app;

/* STATICs -------------------------------------------------------- */

static void cbx_UpdateMenuList(MainWindow*,Menu*,
                                 void(*callback)(void*),int);

/* ---------------------------------------------------------------- */
/* Menu routines */
/* ---------------------------------------------------------------- */

static void cbx_UpdateMenuList(MainWindow* mw,Menu* m,
                                 void(*callback)(void*),int flag)
{
  ManagedObject object;

#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) enter ...\n",PREFUN,(void*)&mw->mlist);
#endif

  object.object   = (void*)m;
  object.callback = callback;

  if (flag > 0) CBX_AddList(&(mw->mlist),&object);  /* add to list */
  else          CBX_RemList(&(mw->mlist),&object);
#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) done\n",PREFUN,(void*)&mw->mlist);
#endif
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoDrop(MainWindow* mw,Menu* m,int x,int y,int w,int h,
                          char* title,void(*callback)(void*))
{
  return(CBX_CreateAutoDrop_Ext(mw,m,mw->win,mw->gfs,x,y,w,h,title,callback));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoDrop_Ext(MainWindow* mw,Menu* m,Window parent,GfC gfs,
                              int x,int y,int w,int h,char* title,
                              void(*callback)(void*))
{
  Window win;

  win = CBX_CreateDropMenu_Ext(mw,m,parent,gfs,x,y,w,h,title);
  m->mode |= CBX_AUTO;
  CBX_SelectInput_Ext(mw->disp,m->win,ButtonPressMask |
                      ButtonReleaseMask);
  cbx_UpdateMenuList(mw,m,callback,1);

  return(win);
}

/* ---------------------------------------------------------------- */

Window CBX_CreateDropMenu(MainWindow* mw,Menu* m,int x,int y,int w,int h,
                          char* title)
{
  return(CBX_CreateDropMenu_Ext(mw,m,mw->win,mw->gfs,x,y,w,h,title));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateDropMenu_Ext(MainWindow* mw,Menu* menu,Window parent,GfC gfs,
                              int x,int y,int w,int h,char* title)
{
  Window win;

  menu->mwin = mw;
  menu->disp = mw->disp;
  menu->gfs  = gfs;
  menu->bg   = cbx_app->beige;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,1,cbx_app->black,menu->bg);
  XSelectInput(mw->disp,win,ButtonPressMask | ButtonReleaseMask);
  XMapRaised(mw->disp,win);
  CBX_Unlock();

  menu->win  = win;
  menu->type = MENU_DROP;
  menu->x    = x;                      /* geometry */
  menu->y    = y;
  menu->w    = w;
  menu->h    = h;
  menu->n    = 0;                      /* # of entries */
  menu->sel  = 0;                      /* selected entry */
  menu->flag = CBX_NORMAL;
  menu->mode = 0;
  if (title) (void)strcpy(menu->title,title);
  else       (void)strcpy(menu->title,"");

  return(win);
} 

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoPopup(MainWindow* mw,Menu* m,int x,int y,int w,int h,
                            void(*callback)(void*))
{
  return(CBX_CreateAutoPopup_Ext(mw,m,mw->win,mw->gfs,x,y,w,h,callback));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoPopup_Ext(MainWindow* mw,Menu* m,Window parent,GfC gfs,
                               int x,int y,int w,int h,void(*callback)(void*))
{
  Window win;

  win = CBX_CreatePopupMenu_Ext(mw,m,parent,gfs,x,y,w,h);
  m->mode |= CBX_AUTO;
  CBX_SelectInput_Ext(mw->disp,m->win,ButtonPressMask |
                      ButtonReleaseMask);
  cbx_UpdateMenuList(mw,m,callback,1);

  return(win);
}

/* ---------------------------------------------------------------- */

Window CBX_CreatePopupMenu(MainWindow* mw,Menu* m,int x,int y,int w,int h)
{
  return(CBX_CreatePopupMenu_Ext(mw,m,mw->win,mw->gfs,x,y,w,h));
}

/* ---------------------------------------------------------------- */

Window CBX_CreatePopupMenu_Ext(MainWindow* mw,Menu* menu,Window parent,GfC gfs,
                           int x,int y,int w,int h)
{
  Window win;

  menu->mwin = mw;
  menu->disp = mw->disp;
  menu->gfs  = gfs;
  menu->bg   = cbx_app->beige;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,1,cbx_app->black,menu->bg);
  XSelectInput(mw->disp,win,ButtonPressMask | ButtonReleaseMask);
  XMapRaised(mw->disp,win);
  CBX_Unlock();

  menu->win  = win;
  menu->type = MENU_POPUP;
  menu->x    = x;                      /* geometry */
  menu->y    = y;
  menu->w    = w;
  menu->h    = h;
  menu->n    = 0;                      /* # of entries */
  menu->sel  = 0;                      /* selected entry */
  menu->flag = CBX_NORMAL;
  menu->mode = 0;
  (void)strcpy(menu->title,"");
  (void)strcpy(menu->unknown,"?");

  return(win);
}

/* ---------------------------------------------------------------- */

Window CBX_CreateFreeMenu(MainWindow* mw,Menu* menu,
                          int x,int y,int w,int h,int b)
{
  return(CBX_CreateFreeMenu_Ext(mw,menu,mw->win,x,y,w,h,b));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateFreeMenu_Ext(MainWindow* mw,Menu* menu,Window parent,
                          int x,int y,int w,int h,int b)
{
  Display *disp=mw->disp;
  Window  win;

  menu->mwin = mw;
  menu->disp = disp;
  menu->bg   = mw->bg;
  menu->gfs  = mw->gfs;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(disp,parent,x,y,w,h,b,cbx_app->black,menu->bg);
  XSelectInput(disp,win,ExposureMask | ButtonPressMask | ButtonReleaseMask);
  XMapRaised(disp,win);
  CBX_Unlock();

  menu->win  = win;
  menu->type = MENU_FREE;
  menu->x    = x;                      /* geometry */
  menu->y    = y;
  menu->h    = CBX_TextHeight_Ext(menu->gfs,"Ty")+4;
  menu->w    = menu->h;
  menu->n    = 0;                      /* # of entries */
  menu->sel  = 0;                      /* selected entry */
  menu->flag = CBX_NORMAL;
  menu->mode = 0;
  (void)strcpy(menu->title,"");

  return(win);
}

/* ---------------------------------------------------------------- */

int CBX_AddMenuEntry(Menu* menu,const char* text,int flag)
{
  MenuEntry *me;

  me = &(menu->entry[menu->n]);

  me->flag = flag;
  if (text) (void)strcpy(me->text,text);
  else      (void)strcpy(me->text,"");

  menu->n += 1;

  return(menu->n-1);                   /* return current 'identifier' */
}

/* ---------------------------------------------------------------- */

int CBX_RemMenuEntry(Menu* menu,int r)
{
  MenuEntry *m1,*m2;

  if (r >= menu->n) return(-1);

  while (r < menu->n-1) {              /* remove entry and copy list */
    m1 = &(menu->entry[r]);
    m2 = &(menu->entry[r+1]);
    strcpy(m1->text,m2->text);         /* copy menu entry */
    m1->flag = m2->flag;
    r++;
  }
  menu->n -= 1;

  return(0);
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
