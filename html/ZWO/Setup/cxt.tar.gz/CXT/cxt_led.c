/* ----------------------------------------------------------------
 *
 * cbx_led.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * v4.00  2002-03-27   auto-managed windows / MainWindow [CCB]
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           3              /* debug level */
#endif
 
#define PREFUN          __func__

/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <stdio.h>

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern Application *cbx_app;

/* STATICs -------------------------------------------------------- */

static void cbx_UpdateLedList(MainWindow*,Led*,int);

/* ---------------------------------------------------------------- */
/* Led routines */
/* ---------------------------------------------------------------- */

static void cbx_UpdateLedList(MainWindow* mw,Led* led,int flag)
{
  ManagedObject object;

#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) enter ...\n",PREFUN,(void*)&mw->llist);
#endif

  object.object   = (void*)led;
  object.callback = NULL;

  if (flag > 0) CBX_AddList(&(mw->llist),&object);  /* add to list */
  else          CBX_RemList(&(mw->llist),&object);
#if (DEBUG > 2)
  fprintf(stderr,"%s(%p) done\n",PREFUN,(void*)&mw->llist);
#endif
}

/* ---------------------------------------------------------------- */

Window CBX_CreateAutoLed(MainWindow* mw,Led* led,
                         int x,int y,int w,int h,u_long c1,u_long c2)
{
  Window win;

  win = CBX_CreateLed_Ext(mw,led,mw->win,x,y,w,h,c1);

  led->mode |= CBX_AUTO;
  led->c2    = c2;
  cbx_UpdateLedList(mw,led,1);

  return(win);
}
 
/* ---------------------------------------------------------------- */

Window CBX_CreateLed(MainWindow* mw,Led* led,
                     int x,int y,int w,int h,u_long color)
{
  return(CBX_CreateLed_Ext(mw,led,mw->win,x,y,w,h,color));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateLed_Ext(MainWindow* mw,Led* led,Window parent,
                          int x,int y,int w,int h,u_long color)
{
  Window win;

  led->mwin = mw;
  led->disp = mw->disp;
 
  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,1,cbx_app->black,color);
  XSelectInput(mw->disp,win,None);
  XMapRaised(mw->disp,win);
  CBX_Unlock();
 
  led->win    = win;
  led->x      = x;
  led->y      = y;
  led->w      = w;
  led->h      = h;
  led->bg     = color;
  led->blink  = 0;
  led->mode   = 0;
  led->c1 = led->c2 = color;
 
  return(win);
}

/* ---------------------------------------------------------------- */

void CBX_ChangeLed(Led* led,u_long color)
{
  if (led->bg != color) {
    led->bg = color;
    (void)CBX_Lock(0);
    XSetWindowBackground(led->disp,led->win,color);
    XClearWindow(led->disp,led->win);
    CBX_Unlock();
  }
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
