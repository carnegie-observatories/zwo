/* ----------------------------------------------------------------------
 *
 * cxt_cbut.c
 *
 * create Button(s)
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *
 * ---------------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG             1                     /* debug level */
#endif
 
#define CBX_BTIME         600

/* INCLUDEs ------------------------------------------------------------- */

#define _REENTRANT

#include <string.h>                             /* strcpy() */

#if (DEBUG > 0)
#include <stdio.h>                              /* fprintf() */
#endif

#include "cxt.h"

/* EXTERNs -------------------------------------------------------------- */
 
extern Application *cbx_app;

/* STATICs -------------------------------------------------------------- */

static void cbx_UpdateButtonList(MainWindow*,Button*,
                                 void(*callback)(void*),int);

/* ---------------------------------------------------------------------- */
/* Button routines */
/* ---------------------------------------------------------------------- */

static void cbx_UpdateButtonList(MainWindow* mw,Button* b,
                                 void(*callback)(void*),int flag)
{
  ManagedObject object;

#if (DEBUG > 2)
  fprintf(stderr,"cbx_UpdateButtonList(%p) enter ...\n",(void*)&mw->blist);
#endif

  object.object   = (void*)b;
  object.callback = callback;

  if (flag > 0) CBX_AddList(&(mw->blist),&object);  /* add to list */
  else          CBX_RemList(&(mw->blist),&object);
#if (DEBUG > 2)
  fprintf(stderr,"cbx_UpdateButtonList(%p) done\n",(void*)&mw->blist);
#endif
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateAutoButton(MainWindow* mw,Button* b,int x,int y,
                            int w,int h,char* text,void(*callback)(void*))
{
  return(CBX_CreateAutoButton_Ext(mw,b,mw->win,mw->gfs,x,y,w,h,text,callback));
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateAutoButton_Ext(MainWindow* mw,Button* b,Window parent,GfC gfs,
                                int x,int y,int w,int h,char* text,
                                void(*callback)(void*))
{
  Window win;

  win = CBX_CreateButton_Ext(mw,b,parent,gfs,x,y,w,h,text);
  b->mode |= CBX_AUTO;
  CBX_SelectInput_Ext(mw->disp,b->win,ButtonPressMask |
                  ButtonReleaseMask | EnterWindowMask | LeaveWindowMask);
  cbx_UpdateButtonList(mw,b,callback,1);

  return(win);
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateAutoDButton(MainWindow* mw,Button* b,int x,int y,
                            int w,int h,char* text,u_long c,
                            void(*callback)(void*))
{
 return(CBX_CreateAutoDButton_Ext(mw,b,mw->win,mw->gfs,x,y,w,h,text,c,callback));
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateAutoDButton_Ext(MainWindow* mw,Button* b,Window parent,GfC gfs,
                                 int x,int y,int w,int h,char* text,u_long c,
                                 void(*callback)(void*))
{
  Window win;

  win = CBX_CreateDButton_Ext(mw,b,parent,gfs,x,y,w,h,text,c);
  b->mode |= CBX_AUTO;
  CBX_SelectInput_Ext(mw->disp,b->win,ButtonPressMask |
                  ButtonReleaseMask | EnterWindowMask | LeaveWindowMask);
  cbx_UpdateButtonList(mw,b,callback,1);

  return(win);
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateButton(MainWindow* mw,Button* b,int x,int y,
                        int w,int h,char* text)
{
  return(CBX_CreateButton_Ext(mw,b,mw->win,mw->gfs,x,y,w,h,text));
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateButton_Ext(MainWindow* mw,Button* b,Window parent,GfC gfs,
                            int x,int y,int w,int h,char* text)
{
  Window win;
 
  b->mwin = mw;                                  /* pointer to MainWindow */
  b->disp = mw->disp;
  b->gfs  = gfs;
  b->fg   = cbx_app->black;
  b->bg   = cbx_app->antique;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,1,cbx_app->black,b->bg);
  XSelectInput(mw->disp,win, ButtonPressMask | ButtonReleaseMask |
    EnterWindowMask | LeaveWindowMask);
  XMapRaised(mw->disp,win);
  CBX_Unlock();

  b->win    = win;
  b->x      = x;
  b->y      = y;
  b->w      = w;
  b->h      = h;
  b->flag   = 0; 
  b->status = 0;
  b->symbol = 0;                            /* no symbol */
  b->mode   = CBX_CENTERED;                 /* default */
  b->blink  = CBX_BTIME;
  if (text) (void)strcpy(b->text,text);
  else      (void)strcpy(b->text,"");
 
  CBX_UpdateButton(b);
 
  return(win);
}

/* ---------------------------------------------------------------------- */

Window CBX_CreateSButton(MainWindow* mw,Button* b,
                             int x,int y,int w,int h,int sym)
{
  return(CBX_CreateSButton_Ext(mw,b,mw->win,mw->gfs,x,y,w,h,sym));
}
 
/* ---------------------------------------------------------------------- */

Window CBX_CreateSButton_Ext(MainWindow* mw,Button* b,Window parent,GfC gfs,
                             int x,int y,int w,int h,int sym)
{
  Window win;
 
  win = CBX_CreateButton_Ext(mw,b,parent,gfs,x,y,w,h,NULL);
  b->mode  &= ~CBX_CENTERED;              /* left justified */
  b->symbol = sym;
 
  CBX_UpdateButton(b);

  return(win);
}
 
/* ---------------------------------------------------------------------- */

Window CBX_CreateDButton(MainWindow *mw,Button* b,int x,int y,int w,int h,
                         char* text,u_long color)
{
  return(CBX_CreateDButton_Ext(mw,b,mw->win,mw->gfs,x,y,w,h,text,color));
}

/* ---------------------------------------------------------------------- */
 
Window CBX_CreateDButton_Ext(MainWindow* mw,Button* b,Window parent,GfC gfs,
                             int x,int y,int w,int h,char* text,u_long color)
{
  Window win;
 
  win = CBX_CreateButton_Ext(mw,b,parent,gfs,x,y,w,h,text);
 
  b->mode  &= ~CBX_CENTERED;              /* left justified */
  b->color  = color;                      /* dot color */
  b->symbol = CBX_DOT;

  CBX_UpdateButton(b);
 
  return(win);
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
 
