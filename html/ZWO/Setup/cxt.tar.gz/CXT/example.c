/* ----------------------------------------------------------------
 *  
 * example.c
 * 
 * Christoph C. Birk (birk@obs.carnegiescience.edu)
 * 
 * copy 'example.c' to the 'CXT' directory
 * compile with:
 * gcc -Wall -m32 -I. example.c -lm -lpthread -lX11 -L. -lcxt
 * gcc -Wall -m64 -I. example.c -lm -lpthread -lX11 -L. -lcxt64
 *
 * ---------------------------------------------------------------- */

/* DEFINEs -------------------------------------------------------- */

#define DEBUG           0

#define P_TITLE         "CXT-Example"
#define P_VERSION       "1.0.1"

#define DEF_BROWSER     "firefox"
#define DEF_HELP        "http://www.example.com"

/* INCLUDEs ------------------------------------------------------- */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <cxt.h>

/* X-DEFINEs ------------------------------------------------------ */

/* these define the window and GUI elements geometry */

#ifdef FONTSIZE
static int  PXh=FONTSIZE;
#else
static int  PXh=14;
#endif

#define PXw        (10+(PXh-14)/2)
#define XXh        (PXh+5)

#define FIMx       2                   /* 'File' menu */ 
#define FIMy       2
#define FIMw       (5*PXw)
enum file_enum { FILE_HELP,FILE_DUMMY,FILE_EXIT };

 
#define OPMx       (FIMx+FIMw+PXw/2)   /* Options - menu */
#define OPMy       2
#define OPMw       (8*PXw)
enum options_enum { OPT_PARAM,OPT_TOGGLE };

#define LINE1y     (FIMy+XXh+PXh/3)    /* ------------------------- */

#define EDT1x      (8*PXw)             /* edit window geomentry */
#define EDT1y      (LINE1y+PXh/3)
#define EDT1w      (8*PXw)

#define EDT2x      (EDT1x)
#define EDT2y      (EDT1y+XXh+PXh/2)
#define EDT2w      (EDT1w)

#define BUT1x      (EDT2x)             /* button geometry */
#define BUT1y      (EDT2y+XXh+PXh/2)
#define BUT1w      (EDT2w)

#define LINE2y     (BUT1y+XXh+PXh/2)   /* ------------------------- */

#define PPM1x      (EDT1x)             /* popup menu geometry */
#define PPM1y      (LINE2y+PXw/2)
#define PPM1w      (EDT1w)
 
#define eWIDE      (EDT1x+EDT1w+8*PXw) /* exposure geometry */
#define eHIGH      (PPM1y+XXh+PXh/3)
 
/* STATICs -------------------------------------------------------- */

static Application *app;
static MainWindow mwin;

static Menu       fimenu;              /* drop down menus */
static Menu       opmenu;
static Menu       ppmenu;              /* popup menu */

static EditWindow edt1,edt2;           /* edit window(s) */

static Button     but1;                /* button(s) */

static Led        led1;                /* "LED" */

static Bool       done=False;

/* function prototype(s) ------------------------------------------ */

static void    redraw_text   (void);

static void    cb_file       (void*);
static void    cb_options    (void*);
static void    cb_ppmenu     (void*);
static void    cb_edt        (void*);
static void    cb_but1       (void*);

static void    update_leds   (void);

static const char*  getenv2  (char*,const char*);

/* --- M A I N ---------------------------------------------------- */

int main(int argc,char **argv)
{
  int        i,sleeptime=0,winpos=CBX_TOPRIGHT;
  char       buffer[1024];
  char       xserver[128],fontname[128];
  XEvent     event;                    /* X-event type structure/union */
  XSizeHints hint;                     /* X-Window geometry structure */

  /* here comes the code ------------------------------------------ */ 

  strcpy(xserver,getenv2("DISPLAY",""));
  strcpy(fontname,getenv2("MYFONT","lucidatypewriter"));

  { extern char *optarg;               /* parse command line */
    extern int opterr,optopt,optind; opterr=0;
    while ((i=getopt(argc,argv,"x:f:h:g:")) != EOF) {
      switch (i) {
      case 'x':                        /* X-server */
        strcpy(xserver,optarg);
        break;
      case 'f':                        /* font family */
        strcpy(fontname,optarg);
        break;
      case 'h':                        /* font height */
        PXh = atoi(optarg);
        break;
      case 'g':                        /* geometry */
        { int x,y; u_int w,h;
          XParseGeometry(optarg,&x,&y,&w,&h);
          winpos = CBX_CalcPosition(x,y);
        }
        break;
      case '?':
        fprintf(stderr,"%s: option '-%c' unknown or parameter missing\n",
                P_TITLE,(char)optopt);
        exit(1);
      }
    } 
  }

  /* initialize X-stuff ------------------------------------------- */
 
  if ((app=CBX_InitXlib(xserver)) == NULL) { /* connect to 'xserver' */
    fprintf(stderr,"%s: CBX_InitXlib(%s) failed\n",argv[0],xserver);
    exit(1);
  }

  /* create main window ------------------------------------------------- */ 
 
  sprintf(buffer,"%s (v%s)",P_TITLE,P_VERSION);
  (void)CXT_OpenMainWindow(&mwin,winpos,eWIDE,eHIGH,&hint,buffer,P_TITLE,True);
  (void)CBX_CreateGfC(&mwin,fontname,"bold",PXh);

  /* create dropdown menus */

  (void)CBX_CreateAutoDrop(&mwin,&fimenu,FIMx,FIMy,FIMw,XXh,"File",cb_file);
    (void)CBX_AddMenuEntry(&fimenu,"Help",0);
    (void)CBX_AddMenuEntry(&fimenu,NULL,  CBX_SEPARATOR);
    (void)CBX_AddMenuEntry(&fimenu,"Exit",0);

  (void)CBX_CreateAutoDrop(&mwin,&opmenu,OPMx,OPMy,OPMw,XXh,"Options",
                           cb_options);
    (void)CBX_AddMenuEntry(&opmenu,"ParameterBox",0);
    (void)CBX_AddMenuEntry(&opmenu,"Enable/Disable Button",0);

  /* create popup menu */

  (void)CBX_CreateAutoPopup(&mwin,&ppmenu,PPM1x,PPM1y,PPM1w,XXh,cb_ppmenu);
    CBX_AddMenuEntry(&ppmenu,"green",0);
    CBX_AddMenuEntry(&ppmenu,"red",0);
  ppmenu.sel = 0;

 (void)CBX_CreateLed(&mwin,&led1,ppmenu.x+ppmenu.w+PXw/2,ppmenu.y+4,
                     PXw,PXw,app->lgrey);

  /* create edit windows */

  (void)CBX_CreateAutoEdit(&mwin,&edt1,EDT1x,EDT1y,EDT1w,XXh,NULL,
                           CBX_VALUE|CBX_OVERWRITE,cb_edt);
  (void)CBX_CreateAutoEdit(&mwin,&edt2,EDT2x,EDT2y,EDT2w,XXh,NULL,
                           0,cb_edt);

  /* buttons */

  (void)CBX_CreateAutoButton(&mwin,&but1,BUT1x,BUT1y,BUT1w,XXh,
                             "PressMe",cb_but1);

  update_leds();

  /* this loop drives the program --------------------------------- */ 

  while (!done) {                      /* main loop */
    while (!CBX_AutoEvent(&mwin,&event,&sleeptime)) {
      CBX_Sleep(&sleeptime,5,300);     /* blocking-time < 300ms */
      if (done) break;
    }
    if (done) break;                   /* break main loop */
    switch(event.type) {
    case Expose:                       /* main window exposed */
      if (event.xexpose.count == 0) {  /* if last event in queue */
        redraw_text();                 /* redraw everything */
      }
      break;
    case CXT_WM_CLOSE:                 /* window closed */
      done=True;  
      break;
#if (DEBUG > 0)
    case MotionNotify:                 /* pointer motion */
      fprintf(stderr,"%s: unhandled pointer motion\n",P_TITLE);
      break;
#endif
#if (DEBUG > 0)
    case EnterNotify:                  /* window-enter event */
    case LeaveNotify:                  /* window-leave event */
      break;
#endif
#if (DEBUG > 0)
    case ButtonPress:                  /* mouse button pressed */
      fprintf(stderr,"%s: unhandled button press\n",P_TITLE);
      break;
#endif
#if (DEBUG > 0)
    case ButtonRelease:                /* mouse button released */
      fprintf(stderr,"%s: unhandled button release\n",P_TITLE);
      break;
#endif
#if (DEBUG > 0)
    default:
      fprintf(stderr,"unknown event '%d'\n",event.type); 
      break;
#endif
    } /* endswitch(event.type) */
  } /* while(!done) */                 /* end of main-loop */ 

  /* free up all the resources and exit --------------------------- */ 

  if (mwin.disp == NULL) {             /* window got destroyed */
    fprintf(stderr,"%s: window got destroyed\n",P_TITLE);
  }
  CBX_CloseMainWindow(&mwin);          /* cleanup */

  CBX_CloseXlib(True);                 /* close connection to Xserver */

  return 0;
} 

/* ---------------------------------------------------------------- */
 
static void redraw_text(void)
{
  Display *disp=mwin.disp;
  Window  win=mwin.win;
  GC      gc=mwin.gfs.gc;

  (void)CBX_Lock(0);                   /* redraw static text */

  XDrawLine(disp,win,gc,3,LINE1y,eWIDE-3,LINE1y);
 
  XDrawString(disp,win,gc,EDT1x-5*PXw,EDT1y+PXh,"Edit1",5);
  XDrawString(disp,win,gc,EDT2x-5*PXw,EDT2y+PXh,"Edit2",5);
  XDrawString(disp,win,gc,BUT1x-6*PXw,BUT1y+PXh,"Button",6);

  XDrawLine(disp,win,gc,3,LINE2y,eWIDE-3,LINE2y);

  XDrawString(disp,win,gc,PPM1x-5*PXw,PPM1y+PXh,"Popup",5);

  CBX_Unlock();
}

/* ---------------------------------------------------------------- */
 
static void cb_file(void* param)
{
  switch (fimenu.sel) {
  case FILE_HELP:
    { char cmd[512]; AMB *box;
      box = CBX_AsyncMessageOpen(P_TITLE ": startup browser",DEF_HELP);
      sprintf(cmd,"%s %s &",getenv2("BROWSER",DEF_BROWSER),DEF_HELP);
      system(cmd);
      sleep(3);
      CBX_AsyncMessageClose(box);
    }
    break;
  case FILE_EXIT:                      /* exit GUI */
    done = True;
    break;
  }
}

/* ---------------------------------------------------------------- */

static void cb_options(void* param)
{
  char buffer[1024]="";

  switch (opmenu.sel) {
  case OPT_PARAM:                      /* option 1 */
    if (CBX_ParameterBox(P_TITLE,buffer)) {
      printf("you entered '%s'\n",buffer);
    } else {
      printf("cancel\n");
    }
    CBX_ClearAutoQueue(&mwin);
    break;
  case OPT_TOGGLE:                     /* option 2 */
    if (but1.flag & CBX_DISABLED) {
      CBX_EnableButton(&but1);
    } else {
      CBX_DisableButton(&but1,CBX_DISABLED);
    }
    break; 
  }
}

/* ---------------------------------------------------------------- */

static void cb_edt(void* param)
{
  EditWindow *w=(EditWindow*)param;

  printf("%s\n",w->text);
}

/* ---------------------------------------------------------------- */

static void cb_but1(void* param)
{
  Button *but=(Button*)param;

  printf("button1 pressed (%p,%p)\n",param,&but1);

  CBX_ReleaseButton(but);
}

/* ---------------------------------------------------------------- */

static void cb_ppmenu(void* param)
{
  update_leds();
}

/* ---------------------------------------------------------------- */

static void update_leds(void)
{
  if (ppmenu.sel == 0) {
    CBX_ChangeLed(&led1,app->green);
  } else {
    CBX_ChangeLed(&led1,app->red);
  }
}

/* ---------------------------------------------------------------- */

const char *getenv2(char *first,const char *def_pointer)
{
  if (getenv(first) == NULL) return def_pointer;
  return getenv(first);
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

