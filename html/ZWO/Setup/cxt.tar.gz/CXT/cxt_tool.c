/* ----------------------------------------------------------------
 *
 * cxt_tool.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
#define RADS            57.29577951    /* 180/pi */

/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <math.h>                      /* sin(),cos(),tan(),floor() */

#if (DEBUG > 0)
#include <stdio.h>                     /* fprintf() */
#endif

#include "cxt.h"

#define PREFUN  __func__

/* STATICs -------------------------------------------------------- */

static void cbx_get_arc (int,int,int*,double*);


/* ---------------------------------------------------------------- */
/* Arc */
/* ---------------------------------------------------------------- */

static void cbx_get_arc(int d,int h,int* r,double* a)
{
  if (d >= h) { *r = h; *a = 90.; return; }
  *r = h;
  do {
    *r += 1;
    *a  = RADS*asin((double)h/(double)*r);
  } while (*a > RADS*atan((double)h/(double)(*r-d)));
#if (DEBUG > 1)
  fprintf(stderr,"get_arc(%d,%d)=%d,%f\n",d,h,*r,*a);
#endif
}

/* ---------------------------------------------------------------- */

void CBX_DrawArc_Ext(Display* disp,Window win,GC gc,int x,int y,int d,int h,
                     int mode)
{
  int    r,a1,a2;
  double a;

  cbx_get_arc(d,h,&r,&a);

  switch(mode) {
  case 0:                              /* open left */
    x += d-2*r; y -= r;
    break;
  case 1:                              /* open bottom */
    x -= r;     y -= d;
    break;
  case 2:                              /* open right */
    x -= d;     y -= r;
    break;
  case 3:                              /* open top */
    x -= r;     y += d-2*r;
    break;
  default:
#if (DEBUG > 0)
    fprintf(stderr,"%s(): unknown mode=%d\n",PREFUN,mode);
#endif
    return;
  }
  a1 = (int)floor(64.*(((double)(mode)*90.)-a)+0.5);
  a2 = (int)floor(64.*(2.*a)+0.5);
  (void)CBX_Lock(0);
  XDrawArc(disp,win,gc,x,y,2*r,2*r,a1,a2);  /* draw arc */
  CBX_Unlock();
}

/* ---------------------------------------------------------------- */
/* Dot */
/* ---------------------------------------------------------------- */

void CBX_DrawDot_Ext(Display* disp,Window win,GC gc,int x,int y,int d,int h,
                     int mode,int dd,float dp)
{
  int    r;
  double a,a0,a1;

  cbx_get_arc(d,h,&r,&a);

  switch(mode) {
  case 0: x += d-r; break;             /* open left */
  case 1: y += r-d; break;             /* open bottom */
  case 2: x += r-d; break;             /* open right */
  case 3: y += d-r; break;             /* open top */
  default:
#if (DEBUG > 0)
    fprintf(stderr,"%s(): unknown mode=%d\n",PREFUN,mode);
#endif
    return;
  }
#if (DEBUG > 1)
  fprintf(stderr,"%s(): x=%d, y=%d\n",PREFUN,x,y);
#endif
  a0 = (double)mode*90. -a;
  a1 = a0 + 0.05*a+(double)dp*1.9*a;
#if (DEBUG > 1)
  fprintf(stderr,"%s(): a0=%f, a1=%f\n",PREFUN,a0,a1);
#endif
  x += (int)floor((double)r*cos(a1/RADS)+0.5);
  y -= (int)floor((double)r*sin(a1/RADS)+0.5);
#if (DEBUG > 1)
  fprintf(stderr,"CBX_DrawDot_Ext(): x=%d, y=%d\n",x,y);
#endif
  (void)CBX_Lock(0);
  XFillArc(disp,win,gc,x-dd/2,y-dd/2,dd,dd,0,23040);
  CBX_Unlock();
}

/* ---------------------------------------------------------------- */
/* Lens */
/* ---------------------------------------------------------------- */

void CBX_DrawLens_Ext(Display* disp,Window win,GC gc,
                      int x,int y,int d,int h,u_int mode)
{
  if (mode & LENS_CNVC) {
    if (mode & LENS_VERT) CBX_DrawArc_Ext(disp,win,gc,x,y,d,h,1);
    else                  CBX_DrawArc_Ext(disp,win,gc,x,y,d,h,0);
  }
  if (mode & LENS_CNCC) {
    if (mode & LENS_VERT) CBX_DrawArc_Ext(disp,win,gc,x,y,d,h,3);
    else                  CBX_DrawArc_Ext(disp,win,gc,x,y,d,h,2);
  }

  (void)CBX_Lock(0);

  if (mode & LENS_CNTR) {              /* center line */
    if (mode & LENS_VERT) XDrawLine(disp,win,gc,x-h,y,x+h,y);
    else                  XDrawLine(disp,win,gc,x,y-h,x,y+h);
  }

  if (mode & LENS_CNVR) {              /* rectangular extension */
    if (mode & LENS_VERT) {
      XDrawLine(disp,win,gc,x-h,y+1,  x-h,y+2*d);
      XDrawLine(disp,win,gc,x+h,y+1,  x+h,y+2*d);
      XDrawLine(disp,win,gc,x-h,y+2*d,x+h,y+2*d);
    } else {
      XDrawLine(disp,win,gc,x+1,  y-h,x+2*d,y-h);
      XDrawLine(disp,win,gc,x+1,  y+h,x+2*d,y+h);
      XDrawLine(disp,win,gc,x+2*d,y-h,x+2*d,y+h);
    }
  }

  if (mode & LENS_CNCR) {              /* rectangular extension */
    if (mode & LENS_VERT) {
      XDrawLine(disp,win,gc,x-h,y-1,  x-h,y-2*d);
      XDrawLine(disp,win,gc,x+h,y-1,  x+h,y-2*d);
      XDrawLine(disp,win,gc,x-h,y-2*d,x+h,y-2*d);
    } else {
      XDrawLine(disp,win,gc,x-1,  y-h,x-2*d,y-h);
      XDrawLine(disp,win,gc,x-1,  y+h,x-2*d,y+h);
      XDrawLine(disp,win,gc,x-2*d,y-h,x-2*d,y+h);
    }
  }

  CBX_Unlock();
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
