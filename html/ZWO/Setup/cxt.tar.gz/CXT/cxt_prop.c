/* ----------------------------------------------------------------
 *
 * cxt_prop.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <string.h>                    /* strcpy() */
#include <stdio.h>                     /* sprintf() */

#include <X11/Xatom.h>

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern void cbx_FillTextProperty    (XTextProperty*,const char*);

/* STATICs -------------------------------------------------------- */


/* ---------------------------------------------------------------- */
/* Property routines */
/* ---------------------------------------------------------------- */

void CBX_RemoveProperty_Ext(Display* disp,Window win,char* name)
{
  Atom   a;

  (void)CBX_Lock(0);
  a = XInternAtom(disp,name,False);
  if (a != None) XDeleteProperty(disp,win,a);
  CBX_Unlock();
}

/* ---------------------------------------------------------------- */

char* CBX_GetStringProperty_Ext(Display* disp,Window win,Atom a,char* string)
{
  Atom          actual_type;
  int           actual_format;
  u_long        nitems,bytes_left;
  long          *property;
  XTextProperty tp;

  (void)CBX_Lock(0);
  XGetWindowProperty(disp,win,a,0,1,False,AnyPropertyType,
                     &actual_type,&actual_format,
                     &nitems,&bytes_left,(u_char**)&property);

  if (property == NULL) {              /* property does not exist */
    CBX_Unlock();
    (void)strcpy(string,"0");
    cbx_FillTextProperty(&tp,string);  /* create property */
    (void)CBX_Lock(0);
    XSetTextProperty(disp,win,&tp,a);
    XFree((void*)tp.value);
    XSync(disp,False);
  } else {                             /* property does exist */
    if (actual_type == XA_INTEGER) {
      sprintf(string,"%d",*(int*)property); /* get (int) */
    } else
    if (actual_type == XA_STRING) {
      XGetTextProperty(disp,win,&tp,a);     /* get (char*) */
      (void)strcpy(string,(char*)tp.value);
      XFree((void*)tp.value);
    } else {
      (void)strcpy(string,"?type?");        /* unknown type */
    }
    XFree((void*)property);
  }
  CBX_Unlock();

  return(string);

}
/* ---------------------------------------------------------------- */

int CBX_GetIntProperty_Ext(Display *disp,Window win,char* name)
{
  Atom   a,actual_type;
  int    actual_format,value;
  u_long nitems,bytes_left;
  long   *property;

  (void)CBX_Lock(0);

  a = XInternAtom(disp,name,False);
  XGetWindowProperty(disp,win,a,0,1,False,XA_INTEGER,
                     &actual_type,&actual_format,
                     &nitems,&bytes_left,(u_char**)&property);
  if (property == NULL) {              /* property does no exist */
    value = 0;                         /* create property */
    XChangeProperty(disp,win,
                    a,XA_INTEGER,32,PropModeReplace,(u_char*)&value,1);
    XSync(disp,False);
  } else {
    value = *(int*)property;
    XFree((void*)property);
  }
  CBX_Unlock();

  return(value);
}

/* ---------------------------------------------------------------- */

Atom CBX_SetIntProperty_Ext(Display* disp,Window win,char* name,int value)
{
  Atom a;

  (void)CBX_Lock(0);

  a = XInternAtom(disp,name,False);    /* get atom for name */
  XChangeProperty(disp,win,a,XA_INTEGER,32,PropModeReplace,(u_char*)&value,1);

  CBX_Unlock();

  return(a);
}

/* ---------------------------------------------------------------- */

char* CBX_GetTextProperty_Ext(Display* disp,Window win,char* name,char* text)
{
  Atom          a;
  XTextProperty tp;

  (void)CBX_Lock(0);
  a = XInternAtom(disp,name,False);
#if (DEBUG > 0)
  if (a == None) { /* should not happen */
    fprintf(stderr,"no atom '%s'\n",name);
    CBX_Unlock();
    return(NULL);
  }
#endif
  XGetTextProperty(disp,win,&tp,a);    /* get text property */
  if (tp.value == NULL) {              /* does not exist */
#if (DEBUG > 1)
    fprintf(stderr,"CBX_GetTextProperty(%s) does not exist\n",name);
#endif
    CBX_Unlock();
    cbx_FillTextProperty(&tp,"default");
    (void)CBX_Lock(0);
    XSetTextProperty(disp,win,&tp,a);  /* create property */
    XSync(disp,False);
  }
  (void)strcpy(text,(char*)tp.value);
  XFree((void*)tp.value);

  CBX_Unlock();

#if (DEBUG > 1)
  fprintf(stderr,"CBX_GetTextProperty(%s) returns '%s'\n",name,text);
#endif
  return(text);
}

/* ---------------------------------------------------------------- */

Atom CBX_SetTextProperty_Ext(Display* disp,Window win, 
                             const char* name,const char* text)
{
  Atom          a;
  XTextProperty tp;

  (void)CBX_Lock(0);
  a = XInternAtom(disp,name,False);
  CBX_Unlock();
  if (a == None) { /* should not happen */
#if (DEBUG > 0)
    fprintf(stderr,"no atom '%s'\n",name);
#endif
    return(0);
  }
  cbx_FillTextProperty(&tp,text);      /* fill text property */
  (void)CBX_Lock(0);
  XSetTextProperty(disp,win,&tp,a);
  XFree((void*)tp.value);
  CBX_Unlock();

  return(a);
}

/* ---------------------------------------------------------------- */

char* CBX_GetAtomName_Ext(Display* disp,Atom a,char* name)
{
  char *buf;

  (void)CBX_Lock(0);
  buf = XGetAtomName(disp,a);
  if (buf != NULL) {
    (void)strcpy(name,buf);
    XFree((void*)buf);
  } else {
    *name = '\0';
  }
  CBX_Unlock();

  return(name);
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
