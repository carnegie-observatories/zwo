/* ----------------------------------------------------------------
 *
 * cbx_twin.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * v4.00  2002-03-27   auto-managed windows / MainWindow [CCB]
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern Application *cbx_app;

/* ---------------------------------------------------------------- */
/* TWindow routines */
/* ---------------------------------------------------------------- */

Window CBX_CreateTWindow(MainWindow* mw,TWindow* twin,
                         int x,int y,int w,int h,int b)
{
  return(CBX_CreateTWindow_Ext(mw,twin,mw->win,x,y,w,h,b));
}

/* ---------------------------------------------------------------- */

Window CBX_CreateTWindow_Ext(MainWindow* mw,TWindow* twin,Window parent,
                         int x,int y,int w,int h,int b)
{
  Window win;

  twin->mwin     = mw;
  twin->disp     = mw->disp;
  twin->gfs      = mw->gfs;
  twin->bg       = mw->bg;

  (void)CBX_Lock(0);
  win = XCreateSimpleWindow(mw->disp,parent,x,y,w,h,b,cbx_app->black,twin->bg);
  XSelectInput(mw->disp,win,ExposureMask | ButtonPressMask|ButtonReleaseMask);
  XMapRaised(mw->disp,win);
  CBX_Unlock();

  twin->win  = win;
  twin->x    = x;
  twin->y    = y;
  twin->w    = w;
  twin->h    = h;
  twin->flag = CBX_NORMAL;

  return(win);
}

/* ---------------------------------------------------------------- */

void CBX_DisableTWindow(TWindow* twin,int flag)
{
  twin->flag = flag;
  CBX_SelectInput_Ext(twin->disp,twin->win,ExposureMask);
  CBX_SendExpose_Ext(twin->disp,twin->win); 
}

/* ---------------------------------------------------------------- */

void CBX_EnableTWindow(TWindow* twin)
{
  twin->flag = CBX_NORMAL;
  CBX_SelectInput_Ext(twin->disp,twin->win,ExposureMask | 
                      ButtonPressMask | ButtonReleaseMask);
  CBX_SendExpose_Ext(twin->disp,twin->win); 
}

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
