/* ----------------------------------------------------------------
 *
 * cxt.h
 *
 * Christoph C. Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 * 
 * 1995-07-15 initial MPIA version
 * 1998-06-01 1.31 
 * 1999-05-05 initial version 2
 * 2000-10-18 initial version 3
 * 2002-03-27 initial version 4
 * 2015-02-02 WM_DELETE_WINOW -> CXT_WM_CLOSE [v4.070]
 * 2016-12-08 CBX_CreateAutoOutput_Ext(),CBX_CreateAutoEdit_Ext() [v4.080]
 * 2017-06-09 fix CBX_DialogBox() [v4.081]
 *
 * ---------------------------------------------------------------- */
 
#ifndef INCLUDE_CXT_H
#define INCLUDE_CXT_H

/* ---------------------------------------------------------------- */

#ifdef IS_CXTLIB_C
#define EXT_CXT
#else
#define EXT_CXT extern
#endif

/* INCLUDEs ------------------------------------------------------- */
 
#include <pthread.h>                   /* mutex */

#include <X11/X.h>                     /* X-stuff */
#include <X11/Xlib.h>
#include <X11/Xutil.h>

/* DEFINEs -------------------------------------------------------- */

//#define CXTLIB_VERSION    0x4070       /* 2015-02-02 */
//#define CXTLIB_VERSION    0x4080       /* 2016-12-07 */
//#define CXTLIB_VERSION    0x4081       /* 2017-06-09 */
#define CXTLIB_VERSION    0x4082       /* 2024-05-28 */

#define CBX_NORMAL        0            /* .flag bits */
#define CBX_PRESSED       0x0001       /* Button */
#define CBX_ACTIVE        0x0002       /* Button,Edit,Menu */
#define CBX_BLINKING      0x0004       /* Button */
#define CBX_INVERTED      0x0008       /* Button */
#define CBX_DISABLED      0x0010       /* Button,Edit,Menu */
#define CBX_STRONG_BLINK  0x0020

#define CBX_EDIT          0x0040       /* EditWindow */

#define CBX_CHECKED       0x0080       /* Menu */
#define CBX_SEPARATOR     0x0100

#define CBX_INSERT        0x0000       /* .mode bits */
#define CBX_OVERWRITE     0x0002
#define CBX_ENFORCE       0x0003       /* v4.064 */
#define CBX_TEXT          0x0000
#define CBX_VALUE         0x0008
#define CBX_AUTO          0x0010       /* Expose,etc */
#define CBX_CENTERED      0x0020       /* button text */

#define CBX_ALL_EVENTS    0x7fffffff

enum sbutton_symbols {                 /* symbol button types */
  CBX_UP_TRI=1,
  CBX_DN_TRI,
  CBX_RT_TRI,
  CBX_LT_TRI,
  CBX_DOT
};

enum MainWindow_Positions {
  CBX_TOPLEFT=-32000,
  CBX_TOPMID,
  CBX_TOPRIGHT,
  CBX_MIDLEFT,
  CBX_CENTER,
  CBX_MIDRIGHT,
  CBX_BOTTOMLEFT,
  CBX_BOTTOMMID,
  CBX_BOTTOMRIGHT,
  CBX_ALIGNRIGHT,
  CBX_ALIGNLEFT,
  CBX_ALIGNBOTTOM,
  CBX_ALIGNTOP
};

#define CBX_TOPCENTER    CBX_TOPMID
#define CBX_MIDMID       CBX_CENTER
#define CBX_BOTTOMCENTER CBX_BOTTOMMID

enum menu_types { MENU_DROP,MENU_POPUP,MENU_FREE };

#define LENS_VERT        0x8000        /* must be != 0x0000 */
#define LENS_HORZ        0x0000

#define LENS_CNTR        0x0001
#define LENS_CNVC        0x0002
#define LENS_CNCC        0x0004
#define LENS_CNVR        0x0008
#define LENS_CNCR        0x0010

#define CXT_WM_CLOSE     (LASTEvent+17)   /* probably 53 */

/* TYPEDEFs ------------------------------------------------------- */
 
typedef struct {
  GC          gc;
  XFontStruct *f_struct;
} GfC;

typedef struct managed_object_tag {   /* managed object */
  void* object;                       /* eg. EditWindow,Button,Menu */
  void(*callback)();                  /* callback */
} ManagedObject;

typedef struct managed_list_tag {     /* list of managed objects */
  ManagedObject   *olist;             /* pointer to list */
  int             nlist,mlist;        /* #entries, list-size */
  pthread_mutex_t lock;               /* mutex lock */
} ManagedList;
 
typedef struct {                      /* MainWindow */
  char            name[64];
  int             w,h;
  Display         *disp;              /* connection to display */
  int             screen;             /* screen */
  Colormap        cmap;
  Window          win;
  GfC             gfs;
  u_long          bg;                 /* background color */
  ManagedList     elist;              /* list of managed EditWindow(s) */
  ManagedList     blist;              /* list of managed Button(s) */
  ManagedList     mlist;              /* list of managed Menu(s) */
  ManagedList     llist;              /* list of managed Led(s) */
} MainWindow;

typedef struct application_tag {      /* application */
  char       xserver[128];
  Display    *disp;
  pthread_mutex_t lock;
  Window     rwin;                    /* root window */
  int        screen,sw,sh;            /* screen-width, -height */
  Colormap   cmap;
  Bool       local_colormap;
  int        vdepth;
  GfC        gfs;
  u_long     black,white,grey,lgrey,red,green,blue,yellow; /* mandatory */
  u_long     brown,orange,beige,antique;                   /* optional */
  Cursor     busy_cursor,input_cursor;
  MainWindow **mw_list;
} Application;

typedef struct button_tag {           /* Button structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     win;
  GfC        gfs;
  int        x,y,w,h;
  char       text[32];
  int        flag;                    /* DISABLED,ACTIVE,PRESSED,BLINKING */
  int        blink;                   /* time to next blink */
  int        status;                  /* dot on/off */
  u_long     color;                   /* dot color */
  int        symbol;
  int        mode;                    /* CBX_AUTO */
  u_long     bg,fg;                   /* background,foreground color */
} Button;
 
#define EDIT_SIZE 128

typedef struct editwindow_tag {       /* EditWindow structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     win;
  GfC        gfs;
  u_long     bg,fg;                   /* background color */
  int        x,y,w,h;
  int        flag;
  int        cpos;                    /* cursor position */
  Bool       show_cursor;
  int        mode;                    /* overwrite/insert/value/text */
  char       text[EDIT_SIZE],buf[EDIT_SIZE];
#if 0 /* O-O */
  void(*update)(EditWindow*);         /* CBX_UpdateEditWindow */
#endif
} EditWindow;

#undef EDIT_SIZE

typedef struct twindow_tag {          /* TWindow structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     win;
  GfC        gfs;
  int        x,y,w,h;
  u_long     bg;                      /* background color */
  int        flag;
} TWindow;

typedef struct menuentry_tag {
  char text[64];
  int  flag;
} MenuEntry;

typedef struct menu_tag {             /* Menu structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     win;
  GfC        gfs;
  char       title[64];
  int        type;                    /* MENU_DROP,MENU_POPUP,MENU_FREE */
  int        x,y,w,h;
  MenuEntry  entry[64];
  char       unknown[64];
  int        n;
  int        sel;
  int        flag;
  int        mode;                    /* CBX_AUTO */
  u_long     bg;                      /* background color */
} Menu;

typedef struct led_tag {              /* LED structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     win;
  int        x,y,w,h;
  u_long     bg;                      /* actual background color */
  u_long     c1,c2;                   /* regular/inverted color */
  int        blink;                   /* time to next blink */
  int        mode;
} Led;

typedef struct listbox_tag {          /* Listbox structure */
  MainWindow *mwin;                   /* back-pointer to MainWindow */
  Display    *disp;
  Window     listbox;                 /* containing window */
  GfC        gfs;
  u_long     bg;                      /* background color */
  Window     win[64];                 /* list of windows */
  int        n,h;                     /* number/height windows */
  Button     upbut,dnbut,scbut;       /* up/down/scroll buttons */
  Window     scwin;                   /* scroll window */
  int        sch;                     /* scroll window height */
  int        sby;                     /* scroll button y */
  char       **list;                  /* list of text items */
  int        nlist;                   /* number of items */
  int        sel;                     /* selected item */
  int        pos;                     /* list item in top window */
} Listbox;

typedef struct managed_edit_tag {
  EditWindow *ewin;
  void(*callback)();
} ManagedEdit;

typedef struct managed_button_tag {
  Button *but;
  void(*callback)();
} ManagedButton;
 
typedef struct managed_menu_tag {
  Menu *menu;
  void(*callback)();
} ManagedMenu;

typedef struct managed_led_tag {
  Led *led;
  void(*callback)();
} ManagedLed;

typedef struct amb_tag {
  pthread_t        tid;
  Display*         disp;
  GfC              gfs;
  Window           box;
  Button           but;
  char             text[256];
  char             title[128];
  volatile int     done;
} AMB;

/* GLOBALs -------------------------------------------------------- */

#ifndef IS_CXTLIB_C
#define  CBX_InitXlib(n)     CXT_OpenLib(n,CXTLIB_VERSION)
#define  CBX_CloseXlib(b)    CXT_CloseLib(b)
#endif

extern Atom cxt_wmDeleteMessage;       /* extern v4.082 */

/* function prototype(s) */

Application* CXT_OpenLib          (char*,u_int);
void         CXT_CloseLib         (Bool);

void*    CBX_SetFatalErrorHandler (XIOErrorHandler);
Bool     CBX_Lock                 (int);
void     CBX_Unlock               (void);

Bool     CBX_CheckEvent           (MainWindow*,long,XEvent*);
Bool     CBX_CheckEvent_Ext       (Display*,long,XEvent*);
Bool     CBX_WaitEvent            (MainWindow*,XEvent*,int);
Bool     CBX_WaitEvent_Ext        (Display*,XEvent*,int);
Bool     CBX_AutoEvent            (MainWindow*,XEvent*,int*);
Bool     CBX_CheckWindowEvent     (MainWindow*,Window,long,XEvent*);
Bool     CBX_CheckWindowEvent_Ext (Display*,Window,long,XEvent*);
Bool     CBX_WaitWindowEvent      (MainWindow*,Window,long,int,XEvent*);
Bool     CBX_WaitWindowEvent_Ext  (Display*,Window,long,int,XEvent*);

Window   CXT_OpenMainWindow       (MainWindow*,long,int,int,XSizeHints*,
                                   const char*,const char*,Bool);
Window   CXT_OpenMainWindow_Ext   (Display*,MainWindow*,long,int,int,
                                   XSizeHints*,const char*,const char*,Bool);
void     CXT_InterceptWMclose     (Display*,Window);
Window   CBX_OpenMainWindow       (MainWindow*,long,int,int,XSizeHints*,
                                   const char*,const char*,Bool);
Window   CBX_OpenMainWindow_Ext   (Display*,MainWindow*,long,int,int,
                                   XSizeHints*,const char*,const char*,Bool);
void     CBX_CloseMainWindow      (MainWindow*);
void     CXT_RemoveMainWindow     (MainWindow*);
void     CBX_IconifyMainWindow    (MainWindow*);
void     CBX_SetMainWindowBackground (MainWindow*,u_char,u_char,u_char);
void     CBX_SetMainWindowHints   (MainWindow*,XSizeHints*,int,int,int,int);
void     CBX_SetMainWindowProperties (MainWindow*,const char*,const char*,
                                      XSizeHints*);
void     CBX_SetWMProperties_Ext  (Display*,Window,const char*,const char*,
                                   XSizeHints*);
void     CBX_SetMainWindowName    (MainWindow*,const char*);
long     CBX_AlignWithParent      (MainWindow*,int,int,int);
long     CBX_AlignWithWindow      (Window,int,int,int);
long     CBX_CalcPosition         (int,int);
GfC      CBX_CreateGfC            (MainWindow*,const char*,const char*,int);
GfC      CBX_CreateGfC_Ext        (Display*,const char*,const char*,int);
void     CBX_SelectInput          (MainWindow*,long);
void     CBX_SelectInput_Ext      (Display*,Window,long);
int      CBX_TextWidth            (MainWindow*,const char*);
int      CBX_TextWidth_Ext        (GfC,const char*);
int      CBX_TextHeight           (MainWindow*,const char*);
int      CBX_TextHeight_Ext       (GfC,const char*);
void     CBX_DrawString           (MainWindow*,int,int,const char*);
void     CBX_DrawLine             (MainWindow*,int,int,int,int);

Window CBX_CreateAutoButton (MainWindow*,Button*,int,int,int,int,char*,
                             void(*callback)(void*));
Window CBX_CreateAutoButton_Ext(MainWindow*,Button*,Window,GfC,int,int,
                                int,int,char*, void(*callback)(void*));
Window CBX_CreateAutoDButton(MainWindow*,Button*,int,int,int,int,char*,u_long,
                             void(*callback)(void*));
Window CBX_CreateAutoDButton_Ext(MainWindow*,Button*,Window,GfC,int,int,
                                 int,int,char*,u_long,void(*callback)(void*));
Window CBX_CreateButton     (MainWindow*,Button*,int,int,int,int,char*);
Window CBX_CreateButton_Ext (MainWindow*,Button*,Window,GfC,int,int,int,int,
                             char*);
Window CBX_CreateSButton    (MainWindow*,Button*,int,int,int,int,int);
Window CBX_CreateSButton_Ext(MainWindow*,Button*,Window,GfC,int,int,int,int,int);
Window CBX_CreateDButton    (MainWindow*,Button*,int,int,int,int,char*,u_long);
Window CBX_CreateDButton_Ext(MainWindow*,Button*,Window,GfC,int,int,int,int,
                             char*,u_long);

int    CBX_HandleButton     (Button*);
int    CBX_HandleButton3    (Button*,int);
void   CBX_PressButton      (Button*);
void   CBX_ReleaseButton    (Button*);
void   CBX_BlinkButton      (Button*,int);
void   CBX_DisableButton    (Button*,int);
void   CBX_EnableButton     (Button*);
void   CBX_UpdateButton     (Button*);

int    CBX_ParameterBox    (char*,char*);
Bool   CBX_MultiParBox     (char*,char**,char**,int*);
Bool   CBX_AlertBox        (const char*,const char*);
int    CBX_DialogBox       (const char*,const char*,const char*);
void   CBX_MessageBox      (const char*,const char*);
Bool   CBX_MultiSelBox     (const char*,char**,int*,u_long);
Bool   CBX_FileSelector    (char*,char*,char*,int,int);
int    CBX_SelectBox       (const char*,char**);

Window CBX_CreateAutoDrop  (MainWindow*,Menu*,int,int,int,int,char*,
                            void(*callback)(void*));
Window CBX_CreateAutoDrop_Ext (MainWindow*,Menu*,Window,GfC,int,int,int,int,
                                char*,void(*callback)(void*));
Window CBX_CreateDropMenu  (MainWindow*,Menu*,int,int,int,int,char*);
Window CBX_CreateDropMenu_Ext (MainWindow*,Menu*,Window,GfC,int,int,int,int,
                               char*);
Window CBX_CreateAutoPopup (MainWindow*,Menu*,int,int,int,int,
                            void(*callback)(void*));
Window CBX_CreateAutoPopup_Ext (MainWindow*,Menu*,Window,GfC,int,int,int,int,
                                void(*callback)(void*));
Window CBX_CreatePopupMenu (MainWindow*,Menu*,int,int,int,int);
Window CBX_CreatePopupMenu_Ext (MainWindow*,Menu*,Window,GfC,int,int,int,int);
Window CBX_CreateFreeMenu  (MainWindow*,Menu*,int,int,int,int,int);
Window CBX_CreateFreeMenu_Ext(MainWindow*,Menu*,Window,int,int,int,int,int);
int    CBX_AddMenuEntry    (Menu*,const char*,int);
int    CBX_RemMenuEntry    (Menu*,int);
void   CBX_CheckMenu       (Menu*,int,Bool);
int    CBX_HandleMenu      (Menu*);
void   CBX_UpdateMenu      (Menu*);
void   CBX_EnableMenu      (Menu*);
void   CBX_DisableMenu     (Menu*,int);

void  CBX_AddList (ManagedList*,ManagedObject*);
void  CBX_RemList (ManagedList*,ManagedObject*);

Window CBX_CreateAutoEdit     (MainWindow*,EditWindow*,int,int,int,int,
                               char*,int,void(*callback)(void*));
Window CBX_CreateAutoEdit_Ext (MainWindow*,EditWindow*,Window,int,int,int,int,
                               char*,int,void(*callback)(void*));
Window CBX_CreateAutoOutput   (MainWindow*,EditWindow*,int,int,int,int,char*);
Window CBX_CreateAutoOutput_Ext(MainWindow*,EditWindow*,Window,
                                int,int,int,int,char*);
Window CBX_CreateEditWindow   (MainWindow*,EditWindow*,int,int,int,int,int,
                               char*,int);
Window CBX_CreateEditWindow_Ext (MainWindow*,EditWindow*,Window,GfC,
                                 int,int,int,int,int,char*,int);
Window CBX_CreateSimpleWindow (MainWindow*,int,int,int,int,u_long);
Window CBX_CreateSimpleWindow_Ext (Display*,Window,int,int,int,int,u_long);
Window CBX_CreateArea         (MainWindow*,int,int,int,int,u_long);

void   CBX_UpdateEditWindow   (EditWindow*);
void   CBX_CrossEditWindow    (EditWindow*,int);
Bool   CBX_HandleEditWindow   (EditWindow*,XKeyEvent*);
void   CBX_ResetEditWindow    (EditWindow*);
void   CBX_EnableEditWindow   (EditWindow*);
void   CBX_DisableEditWindow  (EditWindow*,int);

void   CBX_ClearAutoQueue     (MainWindow*);
void   CBX_ClearXQueue_Ext    (Display*);
void   CBX_ClearWindowQueue_Ext (Display*,Window);
void   CBX_Sync_Ext           (Display*);
void   CBX_Flush_Ext          (Display*);
void   CBX_Flush              (MainWindow*);
void   CBX_GetRootPos         (Window,int*,int*);
void   CBX_GetRootSize        (Window,int*,int*);
void   CBX_GetGeometry        (Window,int*,int*,int*,int*);

void   CXT_Bell               (int,int);

/* cxt_prop.c */

void   CBX_RemoveProperty_Ext    (Display*,Window,char*);
char*  CBX_GetStringProperty_Ext (Display*,Window,Atom,char*);
int    CBX_GetIntProperty_Ext    (Display*,Window,char*);
Atom   CBX_SetIntProperty_Ext    (Display*,Window,char*,int);
Atom   CBX_SetTextProperty_Ext   (Display*,Window,const char*,const char*);
char*  CBX_GetTextProperty_Ext   (Display*,Window,char*,char*);
char*  CBX_GetAtomName_Ext       (Display*,Atom,char*);

char*  CBX_HostName             (char*);
void   CBX_SendExpose_Ext       (Display*,Window);
int    CBX_Sleep                (int*,int,int);
void   CBX_ResizeMainWindow     (MainWindow*,int,int);
void   CBX_ResizeWindow_Ext     (Display*,Window,int,int);
void   CBX_MoveResizeMainWindow (MainWindow*,long,int,int);
Bool   CBX_IsWindow             (Window);
Bool   CBX_IsWindow_Ext         (Display*,Window);
Bool   CBX_IsMapped             (Window);
Bool   CBX_TopWindow            (Window);
Bool   CBX_TopWindow_Ext        (Display*,Window);
void   CBX_WindowBorder_Ext     (Display*,Window,u_long);
void   CBX_SetCursor_Ext        (Display*,Window,int);
void   CBX_BusyCursor           (Window);
void   CBX_InputCursor          (Window);
void   CBX_NormalCursor         (Window);
void   CBX_NormalCursor_Ext     (Display*,Window);
char   CBX_GetKey               (XEvent*);
long   CBX_GetKeySym            (XEvent*);

/* cxt_led.c */

Window CBX_CreateAutoLed     (MainWindow*,Led*,int,int,int,int,u_long,u_long);
Window CBX_CreateLed         (MainWindow*,Led*,int,int,int,int,u_long);
Window CBX_CreateLed_Ext     (MainWindow*,Led*,Window,int,int,int,int,u_long);
void   CBX_ChangeLed         (Led*,u_long);

void   CBX_BlinkLed          (Led*,int);
void   CBX_UpdateLed         (Led*);

/* cxt_twin.c */

Window CBX_CreateTWindow     (MainWindow*,TWindow*,int,int,int,int,int);
Window CBX_CreateTWindow_Ext (MainWindow*,TWindow*,Window,int,int,int,int,int);
void   CBX_DisableTWindow    (TWindow*,int);
void   CBX_EnableTWindow     (TWindow*);


/* cxt_list.c */

Window CBX_CreateListbox (MainWindow*,Listbox*,int,int,int,int,int,char**,int);
void   CBX_RedrawListbox (Listbox*,Bool);
Bool   CBX_HandleListbox (XEvent*,Listbox*,void(*)());

/* cxt_tool.c */

void   CBX_DrawArc_Ext   (Display*,Window,GC,int,int,int,int,int);
void   CBX_DrawDot_Ext   (Display*,Window,GC,int,int,int,int,int,int,float);
void   CBX_DrawLens_Ext  (Display*,Window,GC,int,int,int,int,u_int);

/* cbx_async.c */

void   CBX_AsyncMessageBox     (const char*,const char*);
AMB*   CBX_AsyncMessageOpen    (const char*,const char*);
void   CBX_AsyncMessageClose   (AMB*);
void   CBX_AsyncMessageUpdate  (AMB*,const char*);

void   CBX_AsyncAbortBoxOpen   (AMB*,const char*,const char*);
void   CBX_AsyncAbortBoxClose  (AMB*);
void   CBX_AsyncAbortBoxUpdate (AMB*,const char*);

/* ---------------------------------------------------------------- */

#endif  /* INCLUDE_CXTLIB_H */

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

