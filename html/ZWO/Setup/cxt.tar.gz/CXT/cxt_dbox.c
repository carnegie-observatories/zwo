/* ----------------------------------------------------------------
 *
 * cxt_dbox.c
 *
 * Xlib - wrappers and convenience functions
 * 
 * Christoph Birk, OCIW, Pasadena, CA (birk@obs.carnegiescience.edu)
 *
 * v4.00  2002-03-27   libcxt.a
 *  4.070 2015-02-03   use CXT_OpenMainWindow()
 *
 * ---------------------------------------------------------------- */

#define IS_CXTLIB_C

/* DEFINEs -------------------------------------------------------- */

#ifndef DEBUG
#define DEBUG           1              /* debug level */
#endif
 
#ifdef FONTSIZE
#define PXh             FONTSIZE
#else
#define PXh             14             /* default fontsize */
#endif
#define PXw             (10+(PXh-14)/2)
#define XXh             (PXh+4)

#define  PREFUN         __func__

/* INCLUDEs ------------------------------------------------------- */

#define _REENTRANT

#include <stdlib.h>                    /* malloc() */
#include <string.h>                    /* strcpy() */
#if (DEBUG > 0)
#include <stdio.h>                     /* fprintf() */
#endif

#include "cxt.h"

/* EXTERNs -------------------------------------------------------- */
 
extern int   cbx_max  (int,int);

/* ---------------------------------------------------------------- */
/* Dialog Boxes */
/* ---------------------------------------------------------------- */

Bool CBX_MultiParBox(char* title,char** legend,char** answer,int* taboo)
{
  MainWindow box;
  int        i,n,w1,w2,w=12*PXw,h=3*PXh;
  const int  OKw=3*PXw,CAw=6*PXw+PXw/2;
  int        done=0;
  XSizeHints hint;
  XEvent     event;
  Button     okbut,cabut;
  EditWindow *pawin;

  w1 = cbx_max(3*PXw,(PXw*strlen(title))/3);
  w2 = cbx_max(5*PXw,(PXw*strlen(title))/2+PXw/2);
  w  = cbx_max(w,w1+w2+3*PXw);
  for (n=0; *legend[n] != '\0'; n++) {
    w1 = cbx_max(w1,  PXw*strlen(legend[n]));
    w2 = cbx_max(w2,2*PXw*strlen(answer[n]));
  }
  w = PXw/2+w1+PXw+w2+PXw;
  h  = 3*PXh+n*(XXh+PXh/2); 
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"MParBox",True);
  for (n=0; *legend[n] != '\0'; n++) {
    w1 = cbx_max(w1,  CBX_TextWidth(&box,legend[n]));
    w2 = cbx_max(w2,2*CBX_TextWidth(&box,answer[n]));
  }
  w = PXw/2+w1+PXw+w2+PXw;
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  pawin = (EditWindow*)malloc(n*sizeof(EditWindow));
  for (i=0; i<n; i++) {
    (void)CBX_CreateEditWindow(&box,&pawin[i],w1+5+PXw,PXh/2+i*(XXh+PXh/2),
                               w2,XXh,2,answer[i],0);
    if (taboo[i]) CBX_DisableEditWindow(&pawin[i],CBX_DISABLED);
  }

  (void)CBX_CreateButton(&box,&okbut,w/4-OKw/2,h-(XXh+PXh/2),OKw,XXh,"OK");
  (void)CBX_CreateButton(&box,&cabut,(2*w)/3-CAw/2,h-(XXh+PXh/2),CAw,XXh,
                         "Cancel");

  while (done == 0) {                  /* main loop */
    (void)CBX_WaitEvent(&box,&event,100);
    switch (event.type) {
    case Expose:                       /* expose event */
      if (event.xexpose.count != 0) break;
      for (i=0; i<n; i++) {
        CBX_DrawString(&box,5,PXh/2+i*(XXh+PXh/2)+PXh,legend[i]);
        CBX_UpdateEditWindow(&pawin[i]);
      }
      CBX_UpdateButton(&okbut);
      CBX_UpdateButton(&cabut);
      break;
    case EnterNotify:                  /* enter window event */
    case LeaveNotify:                  /* leave window event */
      for (i=0; i<n; i++) {
        if (event.xcrossing.window == pawin[i].win) {
          CBX_CrossEditWindow(&pawin[i],event.type); break;
        }
      }
      break;
    case KeyPress:                     /* key press event */
      for (i=0; i<n; i++) {
        if (event.xkey.window == pawin[i].win) {
          (void)CBX_HandleEditWindow(&pawin[i],(XKeyEvent*)&event);
        }
      }
      break;
    case ButtonPress:                  /* button-press event */
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == okbut.win) {
        if (CBX_HandleButton(&okbut) == CBX_PRESSED) done =  1;
      }
      if (event.xbutton.window == cabut.win) {
        if (CBX_HandleButton(&cabut) == CBX_PRESSED) done = -1;
      }
      break;
    } /* endswitch(event.type) */
  } /* while (done == 0) */

  if (done > 0) {                      /* OK */
    for (i=0; i<n; i++) (void)strcpy(answer[i],pawin[i].text);
  }

  CBX_CloseMainWindow(&box);           /* cleanup */
  free((void*)pawin);

  if (done < 0) return(False);
  return(True);
}

/* ---------------------------------------------------------------- */
/* AlertBox */
/* ---------------------------------------------------------------- */

Bool CBX_AlertBox(const char* title,const char* text)
{
  MainWindow box;
  int        w=16*PXw,w2,done=0;
  const int  h=5*PXh,OKw=5*PXw,CAw=7*PXw;
  Button     okbut,cabut;
  XSizeHints hint;
  XEvent     event;

  w = cbx_max(w,cbx_max(PXw*(strlen(title)+3),PXw*(strlen(text)+1)));
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"Alert",True);
  w = cbx_max(w,cbx_max(CBX_TextWidth(&box,title)+3*PXw,
                  w2=CBX_TextWidth(&box,text)+PXw));
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  (void)CBX_CreateButton(&box,&okbut,w/4-OKw/2,h-2*PXh,OKw,XXh,"OK");
  (void)CBX_CreateButton(&box,&cabut,(3*w)/4-CAw/2,h-2*PXh,CAw,XXh,"cancel");

  do {                                 /* event loop */
    (void)CBX_WaitEvent(&box,&event,200);
    switch (event.type) {
    case Expose:                       /* expose event */
      CBX_DrawString(&box,5+(w-w2)/2,PXh+PXh/2,text);
      CBX_UpdateButton(&okbut);
      CBX_UpdateButton(&cabut);
      break;
    case ButtonPress:                  /* button-press event */
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == okbut.win) {  /* OK-button */
        if (CBX_HandleButton(&okbut) == CBX_PRESSED) done = 1;
      }
      if (event.xbutton.window == cabut.win) {  /* cancel-button */
        if (CBX_HandleButton(&cabut) == CBX_PRESSED) done = -1;
      }
      break;
    } /* switch(event.type) */
  } while (done == 0);

  CBX_CloseMainWindow(&box);           /* cleanup */

  if (done < 0) return(False);
  return(True);
}

/* ---------------------------------------------------------------- */
/* DialogBox */
/* ---------------------------------------------------------------- */

int CBX_DialogBox(const char* title,const char* text,const char* buttons)
{
  MainWindow box;
  int        w=2*PXw,w2,done=0,i,j,n=0;
  const int  h=5*PXh;
  char       buffer[1024],*s,*p;
  char       *btxt[32];                /* v4.081 */
  Button     but[32];
  XSizeHints hint;
  XEvent     event;
#if (DEBUG > 1)
  fprintf(stderr,"%s(%s,%s,%s): %x\n",PREFUN,title,text,buttons,CXTLIB_VERSION);
#endif

  strcpy(buffer,buttons); p = buffer;
  while ((s=strchr(p,'|')) != NULL) { 
    *s = '\0';
    btxt[n] = (char*)malloc(1+strlen(p)); strcpy(btxt[n],p);
    w += (strlen(p)+3)*PXw; n++;  
    p = s+1;
  }
  btxt[n] = (char*)malloc(1+strlen(p)); strcpy(btxt[n],p);
  w += (strlen(p)+3)*PXw; n++;

  w = cbx_max(w,cbx_max(PXw*(strlen(title)+3),PXw*(strlen(text)+1)));
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"Dialog",True);
  w = cbx_max(w,cbx_max(CBX_TextWidth(&box,title)+3*PXw,
              w2=CBX_TextWidth(&box,text)+PXw));
  for (i=0,j=2; i<n; i++) {
    (void)CBX_CreateButton(&box,&but[i],j*PXw,h-2*PXh,
                           PXw*(strlen(btxt[i])+1),XXh,btxt[i]);
    j += strlen(but[i].text)+3;
    free((void*)btxt[i]);
  }
#if (DEBUG > 1)
  fprintf(stderr,"%s(%s): w=%d, h=%d\n",PREFUN,title,w,h);
#endif
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  do {                                /* event loop */
    (void)CBX_WaitEvent(&box,&event,200);
    switch (event.type) {
    case Expose:                      /* expose event */
      CBX_DrawString(&box,5+(w-w2)/2,PXh+PXh/2,text);
      for (i=0; i<n; i++) CBX_UpdateButton(&but[i]);
      break;
    case ButtonPress:                 /* button-press event */
      if (event.xbutton.button != 1) break;
      for (i=0; i<n; i++) {
        if (event.xbutton.window == but[i].win) {
          if (CBX_HandleButton(&but[i]) == CBX_PRESSED) done = i+1;
          break;
        }
      }
    } /* switch(event.type) */
  } while (done == 0);

  CBX_CloseMainWindow(&box);           /* cleanup */

  return(done);
}

/* ---------------------------------------------------------------- */
/* ParameterBox */
/* ---------------------------------------------------------------- */

Bool CBX_ParameterBox(char *title,char *answer)
{
  MainWindow box;
  int        done=0,w=16*PXw;
  const int  PAy=PXh/2,OKy=PAy+XXh+PXh,OKw=4*PXw,CAw=6*PXw+PXw/2;
  const int  h=OKy+XXh+PXh/2;
  XSizeHints hint;
  XEvent     event;
  EditWindow pawin;
  Button     okbut,cabut;

  w = cbx_max(w,PXw*(strlen(title)+5));
  w = cbx_max(w,PXw*(strlen(answer)+15));
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"ParBox",True);
  w = cbx_max(w,CBX_TextWidth(&box,title)+5*PXw);
  w = cbx_max(w,CBX_TextWidth(&box,answer)+15*PXw);
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  (void)CBX_CreateEditWindow(&box,&pawin,PXw,PAy,w-2*PXw,XXh,2,answer,0);
  (void)CBX_CreateButton(&box,&okbut,w/4-OKw/2,OKy,OKw,XXh,"OK");
  (void)CBX_CreateButton(&box,&cabut,(2*w)/3-CAw/2,OKy,CAw,XXh,"cancel");

  while (done == 0) {                  /* event loop */
    (void)CBX_WaitEvent(&box,&event,100);
    switch(event.type) {               /* select event response */
    case Expose:                       /* expose event */
      CBX_UpdateEditWindow(&pawin);
      CBX_UpdateButton(&okbut);
      CBX_UpdateButton(&cabut);
      break;
    case EnterNotify:                  /* window crossing */
    case LeaveNotify:
      if (event.xcrossing.window == pawin.win) {
        CBX_CrossEditWindow(&pawin,event.type);
      }
      break;
    case KeyPress:                     /* key pressed in window */
      if (event.xkey.window ==  pawin.win) {
        if (CBX_HandleEditWindow(&pawin,(XKeyEvent*)&event)) done = 1;
      }
      break;
    case ButtonPress:                  /* button-press event */
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == okbut.win) { /* OK-button */
        done =   CBX_HandleButton(&okbut);
      } else
      if (event.xbutton.window == cabut.win) { /* cancel-button */
        done =  -CBX_HandleButton(&cabut);
      }
    }
  } /* while (done == 0) */

  CBX_CloseMainWindow(&box);

  if (done < 0) return(False);
  (void)strcpy(answer,pawin.text);
  return(True);
}

/* ---------------------------------------------------------------- */
/* MessageBox */
/* ---------------------------------------------------------------- */

void CBX_MessageBox(const char* title,const char* text)
{
  MainWindow box;
  int        w1,w2,w=16*PXw,done=0;
  const int  h=5*PXh,OKw=5*PXw;
  Button     okbut;
  XSizeHints hint;
  XEvent     event;

  w1 = PXw*(strlen(title)+3);
  w2 = PXw*(strlen(text)+1);
  w  = cbx_max(w,cbx_max(w1,w2));
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"Message",True);
  w1 = CBX_TextWidth(&box,title)+3*PXw;
  w2 = CBX_TextWidth(&box,text)+PXw;
  w  = cbx_max(w,cbx_max(w1,w2));
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  (void)CBX_CreateButton(&box,&okbut,(w-OKw)/2,h-2*PXh,OKw,XXh,"OK");

  do {                                 /* event loop */
    (void)CBX_WaitEvent(&box,&event,200);
    switch (event.type) {
    case Expose:                       /* expose event */
      CBX_DrawString(&box,PXw/2+(w-w2)/2,2*PXh,text);
      CBX_UpdateButton(&okbut);
      break;
    case ButtonPress:                  /* button-press event */
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == okbut.win) {  /* OK-button */
        if (CBX_HandleButton(&okbut) == CBX_PRESSED) done = 1;
      }
      break;
    } /* switch(event.type) */
  } while (done == 0);

  CBX_CloseMainWindow(&box);           /* cleanup */
}

/* ---------------------------------------------------------------- */

#define Y(i)   (PXh/2+i*(PXh+8))

Bool CBX_MultiSelBox(const char *title,char **items,int *flags,u_long color)
{
  MainWindow box;
  int        i,n_items,w=22*PXw,h=3*PXh,wb=6*PXw,done=0,x;
  const int  OKw=4*PXw,ALw=4*PXw,CAw=6*PXw+PXw/2;
  Button     okbut,cabut,albut,*but;
  XSizeHints hint;
  XEvent     event;

  w = cbx_max(w,PXw*(strlen(title)+3));
  for (n_items=0; *items[n_items] != '\0'; n_items++) {
    wb = cbx_max(wb,PXw*(strlen(items[n_items])+3));
  }
  w  = cbx_max(w,wb+4*PXw);
  h += n_items*(PXh+8);
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"MultiSel",True);
  for (n_items=0; *items[n_items] != '\0'; n_items++) {  /* loop over items */
    wb = cbx_max(wb,CBX_TextWidth(&box,items[n_items])+3*PXw); /* but. width */
  }
  w = cbx_max(w,wb+4*PXw);
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);

  but = (Button*)malloc(n_items*sizeof(Button));  /* allocate buttons */
  if (but == NULL) return(False);
  x = (w-wb)/2;                        /* button x-pos */
  for (i=0; i<n_items; i++) {
    (void)CBX_CreateDButton(&box,&but[i],x,Y(i),wb,XXh,items[i],color);
    but[i].status = flags[i];
  }
  (void)CBX_CreateButton(&box,&okbut,(w/4)-OKw/2,  h-2*PXh,OKw,XXh,"OK");
  (void)CBX_CreateButton(&box,&albut,(w/2)-ALw/2,  h-2*PXh,ALw,XXh,"All");
  (void)CBX_CreateButton(&box,&cabut,(3*w)/4-CAw/2,h-2*PXh,CAw,XXh,"cancel");

  do {                                 /* event loop */
    (void)CBX_WaitEvent(&box,&event,200);
    switch (event.type) {
    case Expose:
      if (event.xexpose.count == 0) {
        for (i=0; i<n_items; i++) CBX_UpdateButton(&but[i]);
        CBX_UpdateButton(&okbut);
        CBX_UpdateButton(&albut);
        CBX_UpdateButton(&cabut);
      }
      break;
    case ButtonPress:
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == okbut.win) {  /* OK-button */
        if (CBX_HandleButton(&okbut) == CBX_PRESSED) done =  1;
      } else
      if (event.xbutton.window == cabut.win) {  /* cancel-button */
        if (CBX_HandleButton(&cabut) == CBX_PRESSED) done = -1;
      } else
      if (event.xbutton.window == albut.win) {  /* All-button */
        if (CBX_HandleButton(&albut) == CBX_PRESSED) {
          int all_status;
          for (i=0; i<n_items; i++) {
            if (but[i].status == 0) break;
          }
          if (i == n_items) all_status = 0;
          else              all_status = 1;
          for (i=0; i<n_items; i++) {
            but[i].status = all_status;
            CBX_UpdateButton(&but[i]);
          }
        }
        CBX_ReleaseButton(&albut);
      } else {
        for (i=0; i<n_items; i++) {
          if (event.xbutton.window == but[i].win) {
            if (CBX_HandleButton(&but[i]) == CBX_PRESSED) {
              if (but[i].status) but[i].status = 0;
              else               but[i].status = 1;
              CBX_ReleaseButton(&but[i]);
            }
            CBX_UpdateButton(&but[i]);
            break;
          }
        } /* endfor(n_items) */
      } /* endif(event.xbutton.window) */
      break;
    }
  } while (done == 0);

  if (done > 0) {
    for (i=0; i<n_items; i++) flags[i] = but[i].status;
  }

  CBX_CloseMainWindow(&box);           /* cleanup */
  free((void*)but);

  if (done < 0) return(False);
  return(True);
}

#undef Y

/* ---------------------------------------------------------------- */

#define Y(i)  (PXh+i*(PXh+8))

int CBX_SelectBox(const char *title,char **items)
{
  MainWindow box;
  int        i,n_items,w,h=4*PXh,wb=6*PXw,done=0;
  const int  CAw=6*PXw+PXw/2;
  Button     cabut,*but;
  XSizeHints hint;
  XEvent     event;

  w = PXw*(4+strlen(title));
  for (n_items=0; *items[n_items] != '\0'; n_items++) { /* count items */
    w = cbx_max(w,PXw*(3+strlen(items[n_items])));
  }
  h += n_items*(PXh+8);
  CXT_OpenMainWindow(&box,CBX_CENTER,w,h,&hint,title,"SelectBox",True);
  w = cbx_max(wb,CBX_TextWidth(&box,title)+4*PXw); /* window width */
  for (i=0; i<n_items; i++) {          /* loop over items */
    wb = cbx_max(wb,CBX_TextWidth(&box,items[i])+PXw);
    w  = cbx_max(w,wb+2*PXw);
  }
  CBX_MoveResizeMainWindow(&box,CBX_CENTER,w,h);
#if (DEBUG > 1)
  fprintf(stderr,"%s() w=%d, h=%d\n",PREFUN,w,h);
#endif

  but = (Button*)malloc(n_items*sizeof(Button));  /* allocate button */
  for (i=0; i<n_items; i++) {
    (void)CBX_CreateButton(&box,&but[i],(w-wb)/2,Y(i),wb,XXh,items[i]);
  }
  (void)CBX_CreateButton(&box,&cabut,(w-CAw)/2,h-2*PXh,CAw,XXh,"cancel");
#if (DEBUG > 1)
  fprintf(stderr,"%s() but=%p\n",PREFUN,(void*)but);
#endif

  while (done == 0) {                  /* event loop */
    (void)CBX_WaitEvent(&box,&event,100);
    switch (event.type) {              /* select event.type */
    case Expose:                       /* expose events */
      if (event.xexpose.count != 0) break;
      for (i=0; i<n_items; i++) CBX_UpdateButton(&but[i]);
      CBX_UpdateButton(&cabut);
      break;
    case ButtonPress:                  /* button press event */
      if (event.xbutton.button != 1) break;
      if (event.xbutton.window == cabut.win) {  /* cancel-button */
        if (CBX_HandleButton(&cabut) == CBX_PRESSED) done = -1;
      } else {
        for (i=0; i<n_items; i++) {             /* select buttons */
          if (event.xbutton.window == but[i].win) {
            if (CBX_HandleButton(&but[i]) == CBX_PRESSED) { done=i+1; break; }
          }
        }
      }
      break;
    }
  } /* while (done == 0) */

  CBX_CloseMainWindow(&box);           /* cleanup */
  free((void*)but);

  if (done > 0) return(done-1);
  return(-1);
}

#undef Y

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
 
